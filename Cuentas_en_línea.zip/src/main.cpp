/* Autores:
        Majo Croche
        Bum Soo Jang
        Oriana Cañizales
    Fecha: 26 de Nov. de 2023
    Propósito: Este programa te permite agregar, eliminar y 
    poder ver tanto cuentas de servicios en línea 
    como tarjetas asociadas, y no asociadas a estas*/

//Se incluyen todas las librerías y archivos necesarios
#include <iostream>
#include "cuenta.cpp"
#include <vector>
using namespace std;

int main(){
    vector <Tarjeta> mistarjetas; //Lista de las tarjetas
    vector <Cuenta> miscuentas; //Lista de las cuentas
    int accion = 0; //La variable accion comienza en 0 para cumplir las condiciones del cilo while


    cout << "Bienvenido a tus cuentas virtuales!" << endl;
    while ((0 <= accion) && (accion < 7)) { //Ciclo que permite la continuacion del programa hasta que el usuario quiera salir
            if (accion == 0) { //Instrucciones para el usuario
                cout << "Escriba el número correspondiente a la acción que desea ejecutar." << endl;
                cout << "1. Ver mis tarjetas" << endl << "2. Ver mis cuentas activas" << endl << 
                "3. Agregar una tarjeta"  << endl << "4. Eliminar una tarjeta" << endl << 
                "5. Agregar una cuenta" << endl << "6. Eliminar una cuenta" << endl <<
                "7. Salir " << endl; cin >> accion;

            } else if (accion == 1){ //Se imprimen todas las tarjetas en orden y numeradas
                cout << "\n";
                cout << "Mis tarjetas" << endl;
                for (int i=0; i<(mistarjetas.size()); i++) {
                    cout << "\n       Tarjeta " << (i+1) << endl;
                    cout << "Datos de la tarjeta\n";
                    cout << mistarjetas[i].to_string() << endl;

                }
                cout << "\n";
                accion = 0;
                
            } else if (accion == 2) { //Se imprimen todas las cuentas en orden y numeradas
                cout << "\n";
                cout << "Mis cuentas" << endl;
                for (int i=0; i<(miscuentas.size()); i++) {
                    cout << "\n       Cuenta " << (i+1) << endl;
                    cout << miscuentas[i].to_string();

                }
                cout << "\n";
                accion = 0;

            } else if (accion == 3) { //Se crea una tarjeta y se une a la lista
                string nombret; //Variables temporales de tarjeta
                int num_tarjetat;
                int vencimientot;
                string tipot;
                int cvvt;
                cout << "\n";
                cout << "Agregue los datos de la tarjeta: " << endl;
                cin.ignore(numeric_limits<streamsize>::max(), '\n'); //Limpia el cin para permitir un buen funcionamiento del getline()
                cout << "Nombre del titular: "; getline(cin, nombret); //Permite tomar strings con espacios
                cout << "Número de tarjeta: "; cin >> num_tarjetat;
                cout << "Año de vencimiento: "; cin >> vencimientot;
                cout << "Tipo de tarjeta: "; cin >> tipot;
                cout << "cvv: "; cin >> cvvt;
                cout << endl;
                Tarjeta tarjeta1(cvvt, nombret, num_tarjetat, vencimientot, tipot); //Crea una tarjeta temporal
                mistarjetas.push_back(tarjeta1); //Agrega la tarjeta al final de la lista
                cout << "\n";
                accion = 0;

            } else if (accion == 4) { //Se elimina una tarjeta de la lista
                int num_tarjeta_a_eliminar;
                cout << "\n";
                cout << "Mis tarjetas" << endl;
                for (int i=0; i<(mistarjetas.size()); i++) {
                    cout << "\n       Tarjeta " << (i+1) << endl;
                    cout << "Datos de la tarjeta\n";
                    cout << mistarjetas[i].to_string() << endl;
                }
                cout << "Ingrese la tarjeta que desea eliminar: "; cin >> num_tarjeta_a_eliminar;
                auto iterador_tarjeta = mistarjetas.begin() + (num_tarjeta_a_eliminar - 1); //Itera a tráves de la lista y elimina la tarjeta deseada (el índice va un número atrás de número de cada tarjeta)
                mistarjetas.erase(iterador_tarjeta);
                cout << "La tarjeta " + to_string(num_tarjeta_a_eliminar) + " fue eliminada exitosamente\n";
                cout << "\n";
                accion = 0;

            } else if (accion == 5) { //Se crea una cuenta y se une al vector de cuentas
                if (mistarjetas.size() != 0) { //Solo se puede crear una cuenta si hay tarjetas creadas
                    string serviciot;
                    string usuariot;
                    string contrat;
                    int num_tarjeta;
                    cout << "\n";
                    cout << "Agregue los datos de la cuenta: " << endl;
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << "Nombre del servicio: "; cin >> serviciot;
                    cout << "Usuario: "; cin >> usuariot;
                    cout << "Contraseña: "; cin >> contrat;
                    cout << "¿Qué tarjeta desea utilizar para el servicio?: ";
                    cin >> num_tarjeta;
                    cout << "\n";
                    Tarjeta tarjetat = mistarjetas[(num_tarjeta-1)];
                    Cuenta cuenta1(serviciot, usuariot, contrat, tarjetat);
                    miscuentas.push_back(cuenta1);
                } else {
                    cout << "\nNo se puede crear una cuenta debido a que no cuenta con tarjetas\n";
                }
                cout << "\n";
                accion = 0;

            } else if (accion == 6) { //Se elimina una cuenta
                int num_cuenta_a_eliminar;
                cout << "\n";
                cout << "Mis cuentas" << endl;
                for (int i=0; i<(miscuentas.size()); i++) {
                    cout << "\n       Cuenta " << (i+1) << endl;
                    cout << miscuentas[i].to_string();
                }
                cout << "Ingrese la cuenta que desea elimiar: "; cin >> num_cuenta_a_eliminar;
                auto iterador_cuenta = miscuentas.begin() + (num_cuenta_a_eliminar - 1);
                miscuentas.erase(iterador_cuenta);
                cout << "La cuenta " + to_string(num_cuenta_a_eliminar) + " fue eliminada exitosamente\n";
                cout << "\n";
                accion = 0;

            } else if (accion == 7) {
                cout << "Salir"; 

            }
        }

    return 0;
}