/* Autores:
        Majo Croche
        Bum Soo Jang
        Oriana Cañizales
    Fecha: 26 de Nov. de 2023
    Propósito: Declarar la clase tarjeta y sus atributos.*/
#include <string>

class Tarjeta{
    private:
        int cvv;
        std::string nombre;
        unsigned long int num_tarjeta;
        int vencimiento;
        std::string tipo;

    public:
        Tarjeta();
        Tarjeta(int,std::string,unsigned long int,int,std::string);

        void setcvv(int);

        int getcvv();
        std::string getNombre();
        unsigned long int getNum_tarjeta();
        int getVencimiento();
        std::string getTipo();

        std::string to_string();

};